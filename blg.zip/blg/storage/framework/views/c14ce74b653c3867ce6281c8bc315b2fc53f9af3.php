<?php $__env->startSection('content'); ?>
<div class="w-4/5 mx-auto my-8">
<?php echo e(Form::open(['method'=>'POST','action'=>'PostsController@store'])); ?>

<?php echo e(Form::text('title','',['class'=>['w-full','block','py-2','px-2','rounded','mt-4','bg-grey-light'],'placeholder'=>'your title here...'])); ?>

<?php echo e(Form::textarea('body','',['class'=>['w-full','block','py-2','px-2','rounded','mt-4','bg-grey-light'],'placeholder'=>'your body here...'])); ?>

<div class="flex items-center justify-around mt-8 ">
<?php echo e(Form::Label('category_id','Category : ')); ?>

<select class="category w-4/5" multiple="multiple" name="Categories">
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>
<?php echo e(Form::submit('Create',['class'=>['mt-8','text-white','rounded','bg-blue-dark','inline-block','py-2','px-2',]])); ?>

<?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

      <script>$('.category').select2();
      
      </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>