<?php $__env->startSection('content'); ?>
<div class="w-4/5 mx-auto my-8">
<?php echo e(Form::open(['action' => ['CommentsController@update', $comment->id],'method'=>'POST'])); ?>

<?php echo e(Form::text('body',$comment->body,['class'=>['w-full','block','py-2','px-2','rounded','mt-4','bg-grey-light'],'placeholder'=>'your title here...'])); ?>

<?php echo e(Form::hidden('_method','PUT')); ?>

<?php echo e(Form::submit('submit',['class'=>['mt-8','text-white','rounded','bg-blue-dark','inline-block','py-2','px-2',]])); ?>

<?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>