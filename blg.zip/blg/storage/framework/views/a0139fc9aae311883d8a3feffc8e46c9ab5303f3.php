<?php $__env->startSection('content'); ?>

<div class="mx-auto mt-16 w-4/5 bg-white shadow px-16 py-8">
        <div class="flex mt-2 mb-8 justify-center items-center">

                <a href="<?php echo e($post->id); ?>/edit" class=" mr-4 rounded inline-block no-underline text-white bg-green-light px-4 py-4 font-semibold">Edit</a>
                <?php echo Form::open(['action' => ['PostsController@destroy',$post->id],'method' => 'POST']); ?>

    <?php echo e(Form::hidden('_method','DELETE')); ?>

    <?php echo e(Form::submit('Delete',['class' => 'mr-4 rounded inline-block no-underline text-white bg-red-light px-4 py-4 font-semibold'])); ?>

<?php echo Form::close(); ?>

        </div>
<p class="text-center text-blue-dark font-bold text-2xl mb-8 "><?php echo e($post->title); ?></p>
<p class="mt-4 "><?php echo e($post->body); ?></p>
<p class="mt-8 text-grey-base text-sm ">Created By : </p>
<div class="flex items-center mt-8">
<a href="#" class=" mr-4 no-underline border border-solid border-red-light rounded inline-block px-2 py-2 text-red-light hover:bg-red-light hover:text-white font-semibold ">Like</a>
<a href="#"  class=" ml-4 no-underline border border-solid border-blue-dark rounded inline-block px-2 py-2 text-blue-dark hover:bg-blue-dark hover:text-white font-semibold">Add Comment</a>
</div>
<p class="text-grey-dark mt-8">Likes </p>
<a href="#comment" class="text-grey-dark mt-2 no-underline inline-block "><?php echo e(count($post->comments)); ?> Comments</a>
<?php echo e(Form::open(['method'=>'POST','action'=>'CommentsController@store'])); ?>

<?php echo e(Form::text('body','',['class'=>['w-4/5','py-2','px-2','rounded','mt-4','bg-grey-light'],'id'=>'comment','placeholder'=>'your comment here...'])); ?>

<?php echo e(Form::hidden('postid',$post->id)); ?>


<?php echo e(Form::submit('Submit',['class'=>['text-white','rounded','bg-blue-dark','inline-block','py-2','px-2',]])); ?>

<?php echo Form::close(); ?>



<div class=" bg-grey-lighter mt-8">
<?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="border border-solid border-grey-light">
        <div class="flex justify-between ">
        <p class="my-2 py-2 px-2  "><?php echo e($comment->body); ?></p>
<div class="flex items-center">
<a href="../comments/<?php echo e($comment->id); ?>/edit" class="text-grey-dark no-underline mr-4 text-sm ">Edit</a>
        <?php echo Form::open(['action' => ['CommentsController@destroy',$comment->id],'method' => 'POST']); ?>

        <?php echo e(Form::hidden('_method','DELETE')); ?>

        <?php echo e(Form::submit('Delete',['class' => 'text-grey-dark no-underline mr-4 text-sm '])); ?>

    <?php echo Form::close(); ?></div>


        </div>
        <p class="px-2 text-grey-dark text-sm">Submitted By : <?php echo e($comment->user->name); ?></p>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

</div>

<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts/app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>