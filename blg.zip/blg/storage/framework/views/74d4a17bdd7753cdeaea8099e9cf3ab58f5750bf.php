<?php $__env->startSection('content'); ?>
    <div class="  bg-white py-16">
        <div class=" bg-white  text-center overlap px-8 py-8 ">
            <p class="text-blue-dark text-3xl mb-16">Start publishing your stories here</p>
            <p class="text-md text-grey-darker mb-12">2 Million people enjoys our  Blog? why would'nt you be one of them ? </p>
            <div class="mt-16 flex items-center flex-wrap justify-around">
            <a href="<?php echo e(route('register')); ?>" class="inline-block  no-underline  rounded text-blue-dark border-solid border border-blue-dark px-4 py-2 ">Sign Up For free</a>
            <p class="text-grey-dark text-sm ">Or</p>
            <a class="inline-block no-underline text-white bg-blue-dark rounded px-4 py-2 " href="<?php echo e(route('login')); ?>">Log In</a>
        </div>
        </div>
</div>

<div>
    <p class="text-center font-bold text-grey-darkest text-3xl mt-8 mb-8">Our Hottset Posts</p>
    <div  class="flex items-center flex-wrap justify-around mb-8">
        <div style="width:250px" class=" shadow mt-4">
            <div class="bg-black h-24"></div>
            <div class="px-4 py-2">
            <p class="text-xl text-blue-darker mb-4">Post Title</title>
            <p class="text-blue-light text-sm mb-4">Created By </p>
            <div class="flex items-center justify-between mb-8">
                <p class="text-sm text-grey-base">Likes</p>
                <p class="text-sm text-grey-base">Comments</p>
            </div>
            <div class="text-center">
            <a href="#" class=" no-underline inline-block text-white bg-blue-dark rounded py-2 px-5 mb-4">Read The Post</a>
            </div>
        </div>
        </div>
        <div style="width:250px" class=" shadow mt-4">
                <div class="bg-black h-24"></div>
                <div class="px-4 py-2">
                <p class="text-xl text-blue-darker mb-4">Post Title</title>
                <p class="text-blue-light text-sm mb-4">Created By </p>
                <div class="flex items-center justify-between mb-8">
                    <p class="text-sm text-grey-base">Likes</p>
                    <p class="text-sm text-grey-base">Comments</p>
                </div>
                <div class="text-center">
                <a href="#" class=" no-underline inline-block text-white bg-blue-dark rounded py-2 px-5 mb-4">Read The Post</a>
                </div>
            </div>
            </div>
            <div style="width:250px" class=" shadow mt-4">
                    <div class="bg-black h-24"></div>
                    <div class="px-4 py-2">
                    <p class="text-xl text-blue-darker mb-4">Post Title</title>
                    <p class="text-blue-light text-sm mb-4">Created By </p>
                    <div class="flex items-center justify-between mb-8">
                        <p class="text-sm text-grey-base">Likes</p>
                        <p class="text-sm text-grey-base">Comments</p>
                    </div>
                    <div class="text-center">
                    <a href="#" class=" no-underline inline-block text-white bg-blue-dark rounded py-2 px-5 mb-4">Read The Post</a>
                    </div>
                </div>
                </div>
        
        
    </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>