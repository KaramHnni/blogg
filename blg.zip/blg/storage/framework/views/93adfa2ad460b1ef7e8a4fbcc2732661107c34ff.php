<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="https://cdn.jsdelivr.net/npm/tailwindcss/dist/tailwind.min.css" rel="stylesheet">
       <script src="https://code.jquery.com/jquery-3.3.1.js"
			  integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
			  crossorigin="anonymous"></script>
       <link href="<?php echo e(asset('css/select2.css')); ?>" rel="stylesheet" />
        <title><?php echo e(config('app.name','Bloggist')); ?></title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
    </head>
    <body class="bg-grey-lightest">
        <?php echo $__env->make('inc.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div>
            
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <script src="<?php echo e(asset('js/select2.full.js')); ?>"></script>
        <?php echo $__env->yieldContent('scripts'); ?>
        </body>
</html>
