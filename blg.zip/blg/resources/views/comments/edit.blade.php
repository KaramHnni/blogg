@extends('layouts/app')
@section('content')
<div class="w-4/5 mx-auto my-8">
{{ Form::open(['action' => ['CommentsController@update', $comment->id],'method'=>'POST']) }}
{{Form::text('body',$comment->body,['class'=>['w-full','block','py-2','px-2','rounded','mt-4','bg-grey-light'],'placeholder'=>'your title here...'])}}
{{Form::hidden('_method','PUT')}}
{{Form::submit('submit',['class'=>['mt-8','text-white','rounded','bg-blue-dark','inline-block','py-2','px-2',]])}}
{!! Form::close() !!}
</div>
@endsection