@extends('layouts/app')
@section('content')
<div class="w-4/5 mx-auto my-8">
{{ Form::open(['method'=>'POST','action'=>'PostsController@store']) }}
{{Form::text('title','',['class'=>['w-full','block','py-2','px-2','rounded','mt-4','bg-grey-light'],'placeholder'=>'your title here...'])}}
{{Form::textarea('body','',['class'=>['w-full','block','py-2','px-2','rounded','mt-4','bg-grey-light'],'placeholder'=>'your body here...'])}}
<div class="flex items-center justify-around mt-8 ">
{{Form::Label('category_id','Category : ')}}
<select class="category w-4/5" multiple="multiple" name="Categories">
    @foreach($categories as $category)

<option value="{{$category->id}}">{{$category->name}}</option>
    @endforeach
</select>
</div>
{{Form::submit('Create',['class'=>['mt-8','text-white','rounded','bg-blue-dark','inline-block','py-2','px-2',]])}}
{!! Form::close() !!}
</div>
@endsection

@section('scripts')

      <script>$('.category').select2();
      
      </script>
@endsection