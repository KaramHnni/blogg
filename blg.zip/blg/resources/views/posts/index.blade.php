@extends('layouts.app')
@section('content')
<div class="flex items-center">
<h1 class="text-center text-blue-dark font-bold mt-4 mb-8 flex-grow text-center ">Posts</h1>
<a href="posts/create" class=" text-right mr-12 no-underline text-white bg-blue-dark px-2 py-2 inline-block rounded ">Create</a>
</div>
@if(count($posts) > 0)
@foreach($posts as $post)
<div class="mx-auto shadow bg-white md:flex md:items-center mb-4  " style="width:90%">
        <div class=" text-center text-blue-light w-32">Post-image</div>
        <div class="ml-4">
        <p class="py-4 text-2xl text-blue-darker">{{$post->title}}</p>
            <p class="pb-2 text-sm text-grey-dark">Created by {{$post->user->name}} at {{$post->created_at}} </p>
            <p class="pb-4 text-md text-grey-darker">{{substr($post->body,0,20)}}... </p>
        
        </div>
        <div class="ml-auto  pr-4 ">
        <a href="posts/{{$post->id}}" class=" no-underline text-white bg-blue-dark rounded py-2 px-4 inline-block">Continue Reading </a>
        </div>
        </div>
        

@endforeach
@else


<p class="text-center text-black text-lg ">There is no posts to display . Be the one who creates the first one ! </p>

@endif

@endsection
