@extends('layouts.app')
@section('content')

    @foreach($categories as $category)

<p>{{$category->name}}</p>

    @endforeach

@endsection