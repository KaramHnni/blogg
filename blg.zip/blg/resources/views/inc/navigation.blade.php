<header class=" bg-blue-dark flex flex-wrap items-center py-4 px-8 justify-between">

        <ul class="md:flex md:items-center  list-reset ">
            <li><a href="/" class="no-underline inline-block text-white px-4 font-bold text-2xl">Bloggist</a></li>
            <li><a href="#" class="no-underline inline-block text-white px-4 text-sm">Services</a></li>
            <li><a href="#" class="no-underline inline-block text-white px-4 text-sm">News</a></li>
            <li><a href="/posts" class="no-underline inline-block text-white px-4 text-sm">Blog</a></li>
        </ul>
        @guest

        <ul class="flex items-center list-reset">
            <li><a href="{{ route('login') }}" class="inline-block no-underline text-white border-solid border  border-white rounded px-4 py-2 mr-2">Log In</a></li>
            <li><a href="{{ route('register') }}" class="inline-block no-underline bg-white rounded text-blue-dark border-solid border border-white px-4 py-2 ml-2">Sign In </a></li>
        </ul>
        
        @else
        <ul class="flex items-center list-reset">
        <li><a href="/home" class="inline-block no-underline text-white border-solid border  border-white rounded px-4 py-2 mr-2">{{ Auth::user()->name }}</a></li>
        <li><a href="{{ route('logout') }}" class="inline-block no-underline bg-white rounded text-blue-dark border-solid border border-white px-4 py-2 ml-2">Logout</a></li>
        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
            @csrf
        </form>
    </ul>
        @endguest



</header>